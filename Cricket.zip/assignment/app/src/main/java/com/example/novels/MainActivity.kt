package com.example.novels

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        val recyclerview = findViewById<RecyclerView>(R.id.recyclerview)
        val adapter: ArticleAdapter = ArticleAdapter(getArticles())
        recyclerview.adapter = adapter
        recyclerview.layoutManager = LinearLayoutManager(this)

    }

    fun getArticles(): List<Article> {
       val articles=ArrayList<Article>()
        articles.add(Article(
           title = "LPL Ticket Booking 2023- LPL 2023 Ticket Booking Date, Prices, How to book online & offline, Stadium Wise Ticket Availability",
            author = "By travis",
            image = R.drawable.p1,
            details = "After the historic first-ever auction of the Lanka Premier League 2023, the fourth season of Sri Lanka’s domestic T20 competition is all set to go underway from Sunday, July 30. A total of five teams will be seen participating in the T20 extravaganza and will lock horns with each other twice during the league stage. Teams will give their all in the league stage to finish on top of the LPL 2023 Points table.\n" +
                    "\n" +
                    "Defending Champions Jaffna Kings will kickstart the season with a game against the last season’s runner-ups Colombo Strikers at R. Premadasa Stadium in Colombo."

        ))


        articles.add(Article(
            title = "5 Instances when a low score was successfully defended in the ODI Asia Cup",
            author = "By graver",
            image = R.drawable.p2,
            details ="The modern day ODI game is all about batters dominating the bowlers. The short boundaries, thicker bats, flat pitches, two new balls, powerplays are some of the rules that have completely tilted the game in the batter's favour. Even a 300-plus total is not considered a safe score nowadays.\n" +
                    "\n" +
                    "Perhaps that is what makes Asia Cup special. One of the game's biggest ODI competitions, the Asia Cup is also one of the most competitive ones. That is the reason why we have witnessed bowlers making their mark in the continental tournament every now and then.\n" +
                    "\n" +
                    "In the 15 editions of the tournament so far, one has seen numerous matches where bowlers helped their team defend a total that is usually considered indefensible. Through this article, we are taking a look at such games where teams managed to defend low scores in the Asia Cup."
        ))


        articles.add(Article(
            title = "Asia Cup: Top 5 records held by India in tournament history",
            author = "By qudir.y ",
            image = R.drawable.p3,
            details ="India are the most successful side in the history of the Asia Cup. They won the first-ever edition of the competition in 1984 as well the first T20I edition played in 2016. As of now, no team has managed to win the Asia Cup more times than India.\n" +
                    "\n" +
                    "India have won the tournament seven times so far - six ODI titles and one T20I title. Sri Lanka are second in the list with six titles followed by Pakistan who have won the tournament twice. Having dominated the tournament more than any other team, India also hold several records in the Asia Cup. \n" +
                    "\n" +
                    "The Men in Blue will have a chance to extend their domination further in the tournament when Asia Cup 2023 gets underway. So as the Rohit Sharma-led side get ready for the upcoming competition, here is a look at five major records held by India in the Asia Cup."
        ))
        articles.add(Article(
            title = "3 youngsters who deserve a spot in India's ODI World Cup squad",
            author = "By yuter",
            image = R.drawable.p4   ,
            details ="All eyes are on the Indian selectors ahead of the much-awaited ICC World Cup 2023. India's consistent failure to win an ICC tournament calls for a major overhaul, and the Indian cricketing fraternity is eagerly waiting for the World Cup team to be announced.\n" +
                    "\n" +
                    "Team India will be under immense pressure to deliver, primarily when the competition is at home. Given the magnitude of the competition, the selectors are unlikely to make wholesome changes. However, one will not bet against some surprising last moment calls.\n" +
                    "\n" +
                    "In 2019, the selectors had sprung a massive surprise by including Vijay Shankar in the team at the last moment, and something similar could happen this year too. So through this article, we are taking a look at three youngsters who could make the cut if the selectors indeed decide to inject some fresh faces into the ODI team."
        ))
        articles.add(Article(
            title = "3 players who can replace David Warner in Tests",
            author = "By broter",
            image = R.drawable.p5,
            details ="David Warner's days in Test cricket are numbered. The Australia star, who has struggled with his form in red-ball cricket in recent months, has already expressed his desire of retiring from Tests during the next home season. Warner wants to bow out of Test cricket in front of his home crowd in Sydney after the New Year's Test against Pakistan.\n" +
                    "\n" +
                    "Warner might not have performed well in Tests in recent months but he has really been a key member of Australia's Test team since making his debut in 2011. So far, he has played 105 Tests for his country and has scored more than 8000 runs with the help of 25 centuries and 34 half-centuries.\n" +
                    "\n" +
                    "Replacing a player of Warner's skillset will definitely be a herculean task for any team in the world, let alone Australia. Fortunately for Australia, they do have some fine options to replace the veteran opener. Through this article, we are taking a look at three players who can replace Warner in Australia's Test team as an opener.\n" +
                    "\n"
        ))
        articles.add(Article(
            title = "3 players who can replace Rohit Sharma as Test captain\n",
            author = "By gewyer ",
            image = R.drawable.p6,
            details ="In the wake of India's humiliating defeat against Australia in the ICC World Test Championship final, there have been widespread calls to remove Rohit Sharma as India's Test captain. The opening batter was appointed the captain in 2022 after Virat Kohli decided to step down as Test captain despite doing exceptionally well. Kohli's surprising call came after being removed as India's T20I and ODI captain.\n" +
                    "\n" +
                    "Rohit did well to take India to the WTC final but failed to lead the team to a win. India flopped with both bat and ball as Australia thrashed the Rohit Sharma-led side by 209 runs to clinch their first-ever WTC title. The defeat has only extended India's long wait for an ICC title.\n" +
                    "\n" +
                    "Desperate fans and several experts have called for a new captain ahead of the new WTC cycle. Few fans have even called for Kohli to be reinstated as Test captain. While Kohli is more than unlikely to retake charge of the Test team, Let us have a look at three possible options for India's new Test captain if Rohit is eventually sacked from his role. "
        ))
        articles.add(Article(
            title = "Bangladesh's 3 top run-getters in a single edition of World Cup\n",
            author = "By fready",
            image = R.drawable.p7,
            details ="Bangladesh have made some rapid progress in the game especially in the ODI format in recent years. One of the biggest reasons behind it is the new crop of players who entered the scene in the second half of the 2000s. The likes of Tamim Iqbal, Shakib Al Hasan, Mahumudullah, Mushfiqur Rahim and a few others laid the foundation for a strong Bangladesh team.\n" +
                    "\n" +
                    "It did not take these talented players long to make Bangladesh a force to be reckoned with in the 50-over format. Defeating India in the 2007 World Cup or England in the 2011 World Cup, and making it to the Asia Cup final in 2012 as well as 2018, are enough to show the huge progress made by the Bangla Tigers in recent years.\n" +
                    "\n" +
                    "Bangladesh will be hoping for another good performance in the upcoming ICC World Cup 2023. They will be banking on their reliable names once again to deliver in the showpiece event. Therefore, Bangladesh will look to put up another impressive campaign in the marquee 50-over tournament to be held in India later this year."
        ))
        articles.add(Article(
            title = "The Ashes: 10 greatest Tests of all time",
            author = "By govinda ",
            image = R.drawable.p8,
            details ="Over the years, The Ashes has given the world of cricket several unforgettable matches and moments. No series in the game is as old and as iconic as the Ashes. And it also won't be wrong to say that the rivalry between Australia and England is the most intense rivalry in the game.\n" +
                    "\n" +
                    "Since the first Ashes Test, that was played way back in 1882, Australia and England have played some absolute classics on the cricket field. So far, the old foes have played a total of 356 Tests against each other. Australia clearly have the upper hand so far, having won 150 Tests while England have emerged victorious in 110 games. In terms of series wins, Australia have won 34 series while England have clinched 32.\n" +
                    "\n" +
                    "In the 141-year-old history of the Ashes, only 6 series have ended in a draw and it shows just how competitive this rivalry is. So as England and Australia get ready for another edition of the Ashes, we take a look at 10 of the greatest Ashes Tests of all time."
        ))




        return articles
    }
}