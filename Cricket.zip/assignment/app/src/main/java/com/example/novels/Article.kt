package com.example.novels


class Article
    (var title:String,
     var author:String,

     var image:Int,

     var details:String) {
}